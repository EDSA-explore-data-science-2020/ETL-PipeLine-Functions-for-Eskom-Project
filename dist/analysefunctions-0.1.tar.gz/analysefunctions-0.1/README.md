Visit [Wiki Eskom-Analyse-Functions](https://github.com/EDSA-explore-data-science-2020/Eskom-Analyse-Functions-/wiki) For Long Description.
